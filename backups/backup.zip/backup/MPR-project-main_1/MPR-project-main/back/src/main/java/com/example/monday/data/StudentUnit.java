package com.example.monday.data;

public enum StudentUnit {

    GDANSK,
    WARSZAWA
}
