package com.example.monday.data;

import java.util.UUID;

public class Lecture {

    private UUID id;

    private String name;
}
